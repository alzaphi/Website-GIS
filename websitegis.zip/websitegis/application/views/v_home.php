<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home Page - Web GIS Stunting Majene</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 10px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
        }
        h1 {
            font-size: 29px;
            text-align: center;
            margin-bottom: 2px; /* Tambahkan margin bawah pada judul untuk memberi ruang */
        }
        .content {
            display: flex;
            align-items: flex-start; /* Atur elemen agar rata atas */
            gap: 20px;
        }
        .description {
            font-size: 20px;
            text-align: justify;
            white-space: pre-line;
            margin-top: -26px;
            width: 50%; /* Tetapkan lebar sebagai 50% */
        }
        .image-container {
            width: 70%; /* Tetapkan lebar sebagai 50% */
        }
        .image-container img {
            width: 100%; /* Pastikan gambar mengisi container */
            height: auto;
            border-radius: 8px;
        }
        @media (max-width: 768px) {
            .content {
                flex-direction: column;
            }
            .description, .image-container {
                width: 100%; /* Tetapkan lebar sebagai 100% pada layar kecil */
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h1> <b> Mapping Interventions and Programs to Prevent Stunting </b> </h1>
        <div class="content">
            <div class="description">
                West Sulawesi Province emerges as the highest in stunting prevalence across Indonesia <a href="https://aksi.bangda.kemendagri.go.id/emonev/DashPrev"> with a prevalence rate of 23.9%.</a> Majene Regency, within West Sulawesi, is identified as the region with the highest number of stunting cases with <a href="https://aksi.bangda.kemendagri.go.id/emonev/DashPrev"> a prevalence rate of 34.4%.</a> We're reaching out to 82 villages all across Majene Regency to set up 32 Posyandu centers and help tackle this problem where it matters most – right in the heart of the community.
            </div>
            <div class="image-container">
                <img src="<?= base_url('binary-admin/') ?>assets/img/stunting.png" alt="Majene Map"/>
            </div>
        </div>
    </div>

</body>
</html>
